# Cyberwave Homesite — designer handoff

This directory is a screened static release of the Cyberwave Homesite. Serve its contents from the root of an HTTPS website. It includes the HTML pages, shared CSS, and root-level WebP images used by those pages. There is no build step or Replit database requirement for this static copy. The original Replit archive and its secret are preserved separately and are **not** included here.

Local check on October 4, 2026: the landing page and `about.html`, `lab.html`, `universe.html`, `portaloperations.html`, and `syndicate-exit.html` all loaded independently from Replit at `127.0.0.1:8772` without browser-console errors. This does not verify every external link, embedded media, mobile layout, or any forms that may depend on a third-party service.

The current public domain is `cyberwavestudios.com`. Leave its DNS pointing to Replit until the new HTTPS site has been checked by the owner. The original Replit app was not changed.
